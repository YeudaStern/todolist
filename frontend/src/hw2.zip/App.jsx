import { useState } from "react";
import Login from "./components/Login.jsx";
import Register from "./components/Register.jsx";
import UserName from "./components/UserName.jsx";
import Users from "./components/Users.jsx";
function App() {
  const [loggedInUsers, setLoggedInUsers] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState(null);

  const handleLogin = (newUser) => {
    const exists = loggedInUsers.find((u) => u.id === newUser.id);

    if (!exists) {
      setLoggedInUsers([...loggedInUsers, newUser]);
    }
  };
  return (
    <div className="w-full h-screen flex flex-col items-center">
      <div className=" p-1">
        <div className="flex gap-8 m-3 mt-14">
          <Login onLoginSuccess={handleLogin} />
          <Register />
        </div>
        <div className=" p-1">
          <div className="flex mt-20 m-3 gap-8">
            <Users onUserSelect={setSelectedUserId} usersList={loggedInUsers} />
            <UserName userId={selectedUserId} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
