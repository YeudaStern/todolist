import { useState } from "react";
import axios from "axios";
const Login = ({ onLoginSuccess }) => {
  const [id, setId] = useState("");
  const [pass, setPass] = useState("");
const [error, setError] = useState("");
  const handleLogin = async () => {
    console.log("before");
    try{
   const res = await axios.get(`http://localhost:3000/login?id=${id}&pass=${pass}`);
      
       if (res.status === 200) {
        onLoginSuccess(res.data); 
        setError("");
        
      }
      } catch (err) {
        const { status, data } = err.response;
        console.log(data);
        if (status == 404) setError("שם משתמש וסיסמא לא תקינים");
        else setError(data);
      } //4XX
    console.log("after");
  };
  return (
    <div className="p-8 rounded-2xl shadow-2xl w-full max-w-sm border border-gray-100 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-2 bg-linear-to-bl from-red-400 to-indigo-600"></div>
      <div className="text-center mb-8">
        
        <h2 className="text-3xl font-extrabold text-transparent bg-clip-text bg-linear-to-bl from-red-600 to-indigo-600">
          Welcome Back
        </h2>
        <p className="text-gray-400 text-sm mt-2">Please login to your account</p>
      </div>

      <div className="flex flex-col space-y-5">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <svg className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
          </div>
          <input
            className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-200 focus:border-red-500 focus:ring-2 focus:ring-red-200 outline-none transition-all bg-gray-700 focus:bg-gray-600 text-white"
            type="text"
            placeholder="User ID"
            onChange={(e) => setId(e.target.value)}
          />
        </div>

        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <svg className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <input
            className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-200 focus:border-red-500 focus:ring-2 focus:ring-red-200 outline-none transition-all bg-gray-700 focus:bg-gray-600 text-white"
            type="password"
            placeholder="Password"
            onChange={(e) => setPass(e.target.value)}
          />
        </div>

        <button
          className="w-full bg-gradient-to-bl from-red-400 to-indigo-600 text-white font-bold py-3 rounded-lg shadow-lg hover:shadow-xl hover:scale-[1.02] transform transition duration-300 active:scale-95"
          onClick={handleLogin}
        >
          LOGIN
        </button>

        {error && (
          <div className="text-red-500 text-sm text-center bg-red-50 p-2 rounded border border-red-100">
            {error}
          </div>
        )}
      </div>
    </div>
  );
};
export default Login;
